This is the starter app for Angular 16 Change Detection and State Management

These are files taken from the boot camp on templates and components. The files were modified a bit for this camp



