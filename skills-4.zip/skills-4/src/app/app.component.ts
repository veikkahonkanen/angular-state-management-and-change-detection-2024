import { Component, OnInit, inject } from '@angular/core';
import { ProfileService } from "./profile.service";
import { Subscription } from "rxjs";
//
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
//
export class AppComponent implements OnInit{
  title = 'profile';
  pService = inject(ProfileService);
  status: boolean = false;
  // pService : boolean = false;
  private loginSubscription = new Subscription();
  //
  constructor(/* public pService : ProfileService */) {
    this.pService.logout();
  }
  ngOnInit(): void {
    //this.pService.logout();
    /* this.pService.isLoggedIn.subscribe(status => {
      this.pService = status;
    });
   console.log(this.pService);   */
  }
  /* ngOnDestroy(){
    this.loginSubscription.unsubscribe();
  } */

  logout() {
    this.pService.logout();
  }
}
