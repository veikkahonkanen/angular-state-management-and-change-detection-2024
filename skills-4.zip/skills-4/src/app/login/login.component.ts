import { Component, inject } from '@angular/core';
import { ProfileService } from "./../profile.service";
//
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  pService = inject(ProfileService);

  // constructor(private pService : ProfileService){ };

  loginUser(): void {
    console.log("Before: ", this.pService.isLoggedIn());
    this.pService.login();
    console.log("After: ", this.pService.isLoggedIn());
    // this.pService.login();
  }
}
