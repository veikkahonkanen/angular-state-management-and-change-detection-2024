import { Injectable, signal } from '@angular/core';
import { BehaviorSubject, Observable, of } from "rxjs";

@Injectable({
  providedIn: 'root'
})

export class ProfileService {
  private userStatus$ = new Observable<boolean>();
  isLoggedIn = signal(this.userStatus$);
  // isLoggedIn = signal<boolean>(false);
  // isLoggedIn = new BehaviorSubject<boolean>(false);
  constructor() { }
  login() {
    this.isLoggedIn.set(of(true));
    // this.isLoggedIn.update((prevValue) => true);
    // this.isLoggedIn.next(true);
  }
  logout() {
    this.isLoggedIn.set(of(false));
    // this.isLoggedIn.update((prevValue) => false);
    // this.isLoggedIn.next(false);
    
  }
  loginStatus() {
    // return this.isLoggedIn.asObservable();
  }
}
