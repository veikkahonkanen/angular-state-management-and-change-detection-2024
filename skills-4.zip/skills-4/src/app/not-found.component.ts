import { Component } from '@angular/core';
//
@Component({
  selector: 'app-not-found',
  template: `<h2>Oops! We can't find that resourece!</h2>`
})
//
export class NotFoundComponent  {
//
}
